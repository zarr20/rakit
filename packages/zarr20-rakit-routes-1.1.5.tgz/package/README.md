# @zarr20/rakit-routes (Development)

> Source repository and developer guide for `@zarr20/rakit-routes`.

[![license](https://img.shields.io/npm/l/@zarr20/rakit-routes.svg)](./LICENSE)
[![typescript](https://img.shields.io/badge/TypeScript-Ready-blue.svg)](https://www.typescriptlang.org/)
[![npm](https://img.shields.io/npm/v/@zarr20/rakit-routes.svg)](https://www.npmjs.com/package/@zarr20/rakit-routes)

This repository (`rakit-routes-dev`) contains the TypeScript source code, test suites, build tooling, and release workflows for **`@zarr20/rakit-routes`**.

- **Public NPM Package**: [`https://www.npmjs.com/package/@zarr20/rakit-routes`](https://www.npmjs.com/package/@zarr20/rakit-routes)
- **Distribution Repository**: [`https://github.com/zarr20/rakit-routes`](https://github.com/zarr20/rakit-routes)

---

<!-- LATEST_RELEASE_START -->
## 🆕 What's New in v1.1.5

- ♻️ update React router integration to use generatedRoutes function and conditional Outlet imports
<!-- LATEST_RELEASE_END -->

## 🗂️ Project Architecture

```
rakit-routes/
├── src/                      # Source TypeScript code (Feature-Based Architecture)
│   ├── features/             # Domain feature modules
│   │   ├── cli/              # CLI runner, argument parser, and help display
│   │   │   ├── args.ts
│   │   │   ├── runner.ts
│   │   │   ├── types.ts
│   │   │   └── index.ts
│   │   ├── generator/        # Route list generation and deterministic priority sorting
│   │   │   ├── routeGenerator.ts
│   │   │   ├── routeSorter.ts
│   │   │   ├── types.ts
│   │   │   └── index.ts
│   │   ├── mapper/           # RouterMapper orchestration & auto-computed relative importBase
│   │   │   ├── relativeImport.ts
│   │   │   ├── routerMapper.ts
│   │   │   ├── types.ts
│   │   │   └── index.ts
│   │   ├── resolver/         # Path normalization and URL route conversion ([id], [...slug], 404)
│   │   │   ├── pathResolver.ts
│   │   │   └── index.ts
│   │   ├── guard/            # Role handling, access control, and RouteGuard component
│   │   │   ├── types.ts
│   │   │   ├── evaluator.ts
│   │   │   ├── RouteGuard.ts
│   │   │   └── index.ts
│   │   ├── scanner/          # Recursive file system scanning and static metadata extraction
│   │   │   ├── scanPages.ts
│   │   │   ├── specialFiles.ts
│   │   │   ├── metaExtractor.ts
│   │   │   └── index.ts
│   │   ├── vite/             # Zero-dependency Vite dev server plugin
│   │   │   ├── types.ts
│   │   │   ├── vitePlugin.ts
│   │   │   └── index.ts
│   │   └── writers/          # Template generators (React Router lazy routes with meta)
│   │       ├── reactWriter.ts
│   │       ├── types.ts
│   │       └── index.ts
│   ├── cli.ts                # Binary CLI entry point
│   ├── vite.ts               # Vite subpath entry point
│   └── index.ts              # Main public library export
├── scripts/
│   ├── prepare-npm.js        # Bundles and formats the ./npm distribution package
│   └── deploy-npm.js         # Automated versioning, GitHub sync, and NPM publishing pipeline
├── tests/                    # Vitest unit test suites
│   ├── basic.test.mjs
│   ├── guard.test.mjs
│   ├── metadata.test.mjs
│   └── setup.mjs
├── npm/                      # Distribution repository (tracked separately)
├── build.js                  # esbuild bundler configuration (with auto clean)
└── tsconfig.json             # TypeScript declaration generator configuration
```

---

## 🛠️ Development Setup

### 1. Prerequisites
- Node.js >= 18.0.0
- npm >= 9.0.0

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Tests
```bash
npm test          # Run all unit tests with Vitest
npm run test:watch # Run tests in watch mode
```

### 4. Build Code & Generate Declarations
```bash
npm run build
```
This automatically cleans `dist/`, bundles with `esbuild`, and outputs `.d.ts` declaration files using `tsc`.

---

## 📦 Automated Release & Deployment Pipeline

This package features a single-command automated deployment pipeline:

```bash
# Interactive mode (prompts for patch, minor, major, or custom version):
npm run deploy:npm

# Direct shortcuts:
npm run deploy:npm:patch  # e.g., 1.0.1 → 1.0.2
npm run deploy:npm:minor  # e.g., 1.0.1 → 1.1.0
npm run deploy:npm:major  # e.g., 1.0.1 → 2.0.0
```

### What `npm run deploy:npm` does:
1. Prompts for or applies version bump in `package.json` and `RELEASE.md`.
2. Runs `npm run build:npm` (rebuilding `dist/` and syncing `./npm`).
3. Commits and pushes `rakit-routes-dev` with git tag (`X.X.X` format, without `v` prefix).
4. Commits and pushes `./npm` to the distribution repository (`https://github.com/zarr20/rakit-routes.git`).
5. Automatically executes `npm publish --access public` to publish the updated version to NPM.

---

## 🤝 Contributing

1. Fork the repository.
2. Create your feature branch (`git checkout -b feature/amazing-feature`).
3. Commit your changes (`git commit -m 'feat: add amazing feature'`).
4. Ensure all tests pass (`npm test`).
5. Push to the branch (`git push origin feature/amazing-feature`).
6. Open a Pull Request.

---

## 📄 License

[MIT](./LICENSE) © Rakit (Dzarr Al Ghifari)
